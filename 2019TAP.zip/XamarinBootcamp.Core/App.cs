using GalaSoft.MvvmLight.Ioc;
using GalaSoft.MvvmLight.Views;
using XamarinBootcamp.Core.Services.Abstractions;
using XamarinBootcamp.Core.Services.Implementations;
using XamarinBootcamp.Core.ViewModels;

namespace XamarinBootcamp.Core
{
    public class App
    {
        public static SimpleIoc Container { get; } = SimpleIoc.Default;
        
        private static INavigationService NavService => Container.GetInstance<INavigationService>();

        static App()
        {
        }
        
        public static void InitializeServices()
        {
            // Register Services
            Container.Register<IHttpRequestService, HttpRequestService>();
            Container.Register<IAuthService, AuthService>();
            Container.Register<IStoresService, StoresService>();
            Container.Register<IPromotionsService, PromotionsService>();

            // Register ViewModels
            Container.Register<MainViewModel>();
            Container.Register<LoginViewModel>();
            Container.Register<MenuViewModel>();
            Container.Register<StoreListViewModel>();
            Container.Register<CreateStoreViewModel>();
            Container.Register<PromotionListViewModel>();
            Container.Register<StoreMapViewModel>();
        }
        
        public static void Start()
        {
            NavService.NavigateTo(NavigationConstants.LoginPage);
        }
    }
}