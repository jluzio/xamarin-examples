using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using AsyncAwaitBestPractices.MVVM;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Views;
using XamarinBootcamp.Core.Models;
using XamarinBootcamp.Core.Services.Abstractions;

namespace XamarinBootcamp.Core.ViewModels
{
    public class StoreListViewModel : ViewModelBase
    {
        private readonly INavigationService _navigationService;
        private readonly IStoresService _storesService;
        private readonly IDialogService _dialogService;
        
        private bool _isBusy;
        public bool IsBusy
        {
            get => _isBusy;
            set
            {
                _isBusy = value;
                RaisePropertyChanged(nameof(IsBusy));
            }
        }

        private List<Store> _stores;
        public List<Store> Stores
        {
            get => _stores;
            set
            {
                _stores = value;
                RaisePropertyChanged(nameof(Stores));
            }
        }

        private ICommand _createStoreCommand;
        public ICommand CreateStoreCommand => _createStoreCommand ?? (_createStoreCommand = new RelayCommand(CreateStore));
        
        
        private ICommand _refreshListCommand;
        public ICommand RefreshListCommand => _refreshListCommand ?? (_refreshListCommand = new AsyncCommand(RefreshList));


        public StoreListViewModel(INavigationService navigationService, IStoresService storesService, IDialogService dialogService)
        {
            _navigationService = navigationService;
            _storesService = storesService;
            _dialogService = dialogService;
        }
        
        private async Task RefreshList()
        {
            IsBusy = true;
            try
            {
                Stores = await _storesService.GetStoresAsync();
            }
            catch (Exception e)
            {
                await _dialogService.ShowError("Ocorreu um erro: " + e.Message, string.Empty, null, () => {});
            }
            finally
            {
                IsBusy = false;
            }
        }
        
        private void CreateStore()
        {
            _navigationService.NavigateTo(NavigationConstants.CreateStore);
        }
    }
}