using System;
using System.Threading.Tasks;
using System.Windows.Input;
using AsyncAwaitBestPractices.MVVM;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Views;
using XamarinBootcamp.Core.Services.Abstractions;

namespace XamarinBootcamp.Core.ViewModels
{
    public class LoginViewModel : ViewModelBase
    {
        private readonly INavigationService _navigationService;
        private readonly IDialogService _dialogService;
        private readonly IAuthService _authService;

        private bool _isBusy;
        public bool IsBusy
        {
            get => _isBusy;
            set
            {
                _isBusy = value;
                RaisePropertyChanged(nameof(IsBusy));
                ((AsyncCommand)LoginCommand).RaiseCanExecuteChanged();
            }
        }
        
        private string _username;
        public string Username
        {
            get => _username;
            set
            {
                _username = value;
                RaisePropertyChanged(nameof(Username));
                ((AsyncCommand)LoginCommand).RaiseCanExecuteChanged();
            }
        }

        private string _password;

        public string Password
        {
            get => _password;
            set
            {
                _password = value;
                RaisePropertyChanged(nameof(Password));
            }
        }
        
        private IAsyncCommand _loginCommand;
        public IAsyncCommand LoginCommand => _loginCommand ?? (_loginCommand = new AsyncCommand(LoginAsync, CanLogin));
        
        private ICommand _setUsernameCommand;
        public ICommand SetUsernameCommand => _setUsernameCommand ?? (_setUsernameCommand = new RelayCommand<string>(SetUsername));
        
        private ICommand _setPasswordCommand;
        public ICommand SetPasswordCommand => _setPasswordCommand ?? (_setPasswordCommand = new RelayCommand<string>(SetPassword));

        public LoginViewModel(INavigationService navigationService, IDialogService dialogService, IAuthService authService)
        {
            _navigationService = navigationService;
            _dialogService = dialogService;
            _authService = authService;
        }

        private async Task LoginAsync()
        {
            IsBusy = true;
            try
            {
                await _authService.LoginAsync(Username, Password);
            }
            catch(Exception e)
            {
                await _dialogService.ShowMessage("Ocorreu um erro: " + e.Message, "Erro");
                return;
            }
            finally
            {
                IsBusy = false;
            }

            Username = null;
            Password = null;
            
            _navigationService.NavigateTo(NavigationConstants.MenuPage);
        }
        
        private void SetUsername(string username)
        {
            _username = username;
            ((AsyncCommand)LoginCommand).RaiseCanExecuteChanged();
        }
        
        private void SetPassword(string password)
        {
            _password = password;
            ((AsyncCommand)LoginCommand).RaiseCanExecuteChanged();
        }
        
        private bool CanLogin(object o)
        {
            return 
                !string.IsNullOrWhiteSpace(Username) &&
                !string.IsNullOrWhiteSpace(Password)&&
                !IsBusy;
        }
    }
}