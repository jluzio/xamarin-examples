using GalaSoft.MvvmLight;

namespace XamarinBootcamp.Core.ViewModels
{
    public class StoreMapViewModel : ViewModelBase
    {
        
    }
}