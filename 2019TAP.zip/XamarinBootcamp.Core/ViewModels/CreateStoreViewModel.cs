using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;
using AsyncAwaitBestPractices.MVVM;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Views;
using XamarinBootcamp.Core.Services.Abstractions;

namespace XamarinBootcamp.Core.ViewModels
{
    public class CreateStoreViewModel : ViewModelBase
    {
        private readonly INavigationService _navigationService;
        private readonly IStoresService _storesService;
        private readonly IDialogService _dialogService;
        private readonly ILocationService _locationService;

        private CancellationTokenSource _addressCts;

        private bool _isBusy;
        public bool IsBusy
        {
            get => _isBusy;
            set
            {
                _isBusy = value;
                RaisePropertyChanged(nameof(IsBusy));
            }
        }
        
        private string _name;
        public string Name
        {
            get => _name;
            set
            {
                _name = value;
                RaisePropertyChanged(nameof(Name));
                ((AsyncCommand)CreateStoreCommand).RaiseCanExecuteChanged();
            }
        }
        
        private string _address;
        public string Address
        {
            get => _address;
            set
            {
                _address = value;
                RaisePropertyChanged(nameof(Address));
                ((AsyncCommand)CreateStoreCommand).RaiseCanExecuteChanged();
            }
        }
        
        private string _latitude;
        public string Latitude
        {
            get => _latitude;
            set
            {
                _latitude = value;
                RaisePropertyChanged(nameof(Latitude));
            }
        }
        
        private string _longitude;
        public string Longitude
        {
            get => _longitude;
            set
            {
                _longitude = value;
                RaisePropertyChanged(nameof(Longitude));
            }
        }
        
        private string _photoUrl;
        public string PhotoUrl
        {
            get => _photoUrl;
            set
            {
                _photoUrl = value;
                RaisePropertyChanged(nameof(PhotoUrl));
                ((AsyncCommand)CreateStoreCommand).RaiseCanExecuteChanged();
            }
        }
        
        private string _phone;
        public string Phone
        {
            get => _phone;
            set
            {
                _phone = value;
                RaisePropertyChanged(nameof(Phone));
                ((AsyncCommand)CreateStoreCommand).RaiseCanExecuteChanged();
            }
        }
        
        private ICommand _setNameCommand;
        public ICommand SetNameCommand => _setNameCommand ?? (_setNameCommand = new RelayCommand<string>(SetName));
        
        private ICommand _setAddressCommand;
        public ICommand SetAddressCommand => _setAddressCommand ?? (_setNameCommand = new AsyncCommand<string>(SetAddress));

        private ICommand _setPhotoUrlCommand;
        public ICommand SetPhotoUrlCommand => _setPhotoUrlCommand ?? (_setPhotoUrlCommand = new RelayCommand<string>(SetPhotoUrl));
        
        private ICommand _setPhoneCommand;
        public ICommand SetPhoneCommand => _setPhoneCommand ?? (_setPhoneCommand = new RelayCommand<string>(SetPhone));

        private ICommand _createStoreCommand;
        public ICommand CreateStoreCommand => _createStoreCommand ?? (_createStoreCommand = new AsyncCommand(CreateStore, _ => CanCreate()));

        public CreateStoreViewModel(INavigationService navigationService, IStoresService storesService, IDialogService dialogService, ILocationService locationService)
        {
            _navigationService = navigationService;
            _storesService = storesService;
            _dialogService = dialogService;
            _locationService = locationService;
        }
        
        private async Task CreateStore()
        {
            IsBusy = true;
            try
            {
                await _storesService.CreateStoreAsync(Name, Address, Phone, PhotoUrl, Latitude, Longitude);
            }
            catch (Exception e)
            {
                await _dialogService.ShowMessage("Ocorreu um erro: " + e.Message, string.Empty);
                return;
            }
            finally
            {
                IsBusy = false;
            }

            Name = string.Empty;
            Address = string.Empty;
            PhotoUrl = string.Empty;
            Phone = string.Empty;
            Latitude = string.Empty;
            Longitude = string.Empty;

            _navigationService.GoBack();
        }
        
        private bool CanCreate()
        {
            return
                !IsBusy &&
                !string.IsNullOrWhiteSpace(Name) &&
                !string.IsNullOrWhiteSpace(Address) &&
                !string.IsNullOrWhiteSpace(Phone) &&
                !string.IsNullOrWhiteSpace(PhotoUrl);
        }

        private async Task SetCoordinatesAsync(string address)
        {
            if (_addressCts != null && !_addressCts.IsCancellationRequested)
                _addressCts.Cancel();

            _addressCts = new CancellationTokenSource();

            IsBusy = true;
            
            try
            {
                var location = await _locationService.GetLocationAsync(_address);

                Latitude = location.Latitude;
                Longitude = location.Longitude;
            }
            catch (Exception)
            {
                Latitude = Longitude = string.Empty;
            }
            finally
            {
                IsBusy = false;
            }
        }
    
        private void SetName(string name)
        {
            _name = name;
        }
        
        private async Task SetAddress(string address)
        {
            _address = address;
            await SetCoordinatesAsync(_address);
        }
        
        private void SetLatitude(string latitude)
        {
            _latitude = latitude;
        }
        
        private void SetLongitude(string longitude)
        {
            _longitude = longitude;
        }
        
        private void SetPhotoUrl(string photoUrl)
        {
            _photoUrl = photoUrl; 
        }
        
        private void SetPhone(string phone)
        {
            _phone = phone;
        }
    }
}