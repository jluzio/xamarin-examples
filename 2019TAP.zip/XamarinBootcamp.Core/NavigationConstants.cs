namespace XamarinBootcamp.Core
{
    public static class NavigationConstants
    {
        public static string LoginPage = "LoginPage";
        public static string MenuPage = "MenuPage";
        public static string StoresList = "StoresListPage";
        public static string CreateStore = "CreateStorePage";
        public static string PromotionsList = "PromotionsPage";
        public static string CreatePromotion = "CreatePromotionPage";
        public static string StoreMapPage = "StoreMapPage";
    }
}