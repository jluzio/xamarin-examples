using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using XamarinBootcamp.Core.Models;
using XamarinBootcamp.Core.Services.Abstractions;

namespace XamarinBootcamp.Core.Services.Implementations
{
    public class StoresService : IStoresService
    {
        private readonly IHttpRequestService _httpRequestService;

        public StoresService(IHttpRequestService httpRequestService)
        {
            _httpRequestService = httpRequestService;
        }
        
        public Task<List<Store>> GetStoresAsync(CancellationToken ct = default)
        {
            return _httpRequestService.GetAsync<List<Store>>("stores", ct);
        }

        public async Task<Store> GetStoreByIdAsync(string storeId, CancellationToken ct = default)
        {
            var storeList = await _httpRequestService.GetAsync<List<Store>>("stores", ct).ConfigureAwait(false);

            var store = storeList.FirstOrDefault(w => w.Id == storeId);

            return store;
        }

        public Task CreateStoreAsync(Store store, CancellationToken ct = default)
        {
            return _httpRequestService.PostAsync("stores", store, ct);
        }

        public Task CreateStoreAsync(string name, string address, string phone, string photoUrl, string lat, string lng,
            CancellationToken ct = default)
        {
            var store = new Store
            {
                Id = DateTime.Now.ToString("yyyyMMddHHmmss"),
                Name = name,
                Address = address,
                Phone = phone,
                PhotoUrl = photoUrl,
                Lat = lat,
                Lng = lng
            };
            
            return _httpRequestService.PostAsync("stores", store, ct);
        }

        public Task DeleteStoreAsync(string storeId, CancellationToken ct = default)
        {
            throw new System.NotImplementedException();
        }
    }
}