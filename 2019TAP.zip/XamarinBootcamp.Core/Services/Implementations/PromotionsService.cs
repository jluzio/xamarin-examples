using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using XamarinBootcamp.Core.Models;
using XamarinBootcamp.Core.Services.Abstractions;

namespace XamarinBootcamp.Core.Services.Implementations
{
    public class PromotionsService : IPromotionsService
    {
        private readonly IHttpRequestService _httpRequestService;

        public PromotionsService(IHttpRequestService httpRequestService)
        {
            _httpRequestService = httpRequestService;
        }
        
        public Task<List<Promotion>> GetPromotionsAsync(string storeId = null, CancellationToken ct = default)
        {
            var resource = storeId == null ? "promotions" : $"promotions/{storeId}";
            return _httpRequestService.GetAsync<List<Promotion>>(resource, ct);
        }

        public Task CreatePromotionAsync(Promotion promotion, CancellationToken ct = default)
        {
            return _httpRequestService.PostAsync("promotions", promotion, ct);
        }

        public Task CreatePromotionAsync(string product, string storeId, int discount, CancellationToken ct = default)
        {
            var promotion = new Promotion
            {
                Id = DateTime.Now.ToString("yyyyMMddHHmmss"),
                Product = product,
                Discount = discount,
                StoreId = storeId
            };

            return _httpRequestService.PostAsync("promotions", promotion, ct);
        }
        
        public Task DeletePromotionAsync(string promotionId, CancellationToken ct = default)
        {
            throw new System.NotImplementedException();
        }
    }
}