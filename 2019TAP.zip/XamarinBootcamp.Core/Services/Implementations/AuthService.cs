using System.Threading;
using System.Threading.Tasks;
using XamarinBootcamp.Core.Models;
using XamarinBootcamp.Core.Services.Abstractions;

namespace XamarinBootcamp.Core.Services.Implementations
{
    public class AuthService : IAuthService
    {
        private readonly IHttpRequestService _httpRequestService;

        public AuthService(IHttpRequestService httpRequestService)
        {
            _httpRequestService = httpRequestService;
        }
        
        public async Task LoginAsync(string username, string password, CancellationToken ct = default(CancellationToken))
        {
            var user = new User()
            {
                Username = username,
                Password = password
            };

            var result = await _httpRequestService.PostAsync<User>("Users/Login", user, ct);
        }

        public Task LogoutAsync(CancellationToken ct = default(CancellationToken))
        {
            return Task.CompletedTask;
        }

        public bool IsUserAuthenticated()
        {
            return true;
        }

        public User.UserType GetAuthenticatedUserType()
        {
            return User.UserType.Admin;
        }
    }
}