using System.Threading;
using System.Threading.Tasks;
using XamarinBootcamp.Core.Models;

namespace XamarinBootcamp.Core.Services.Abstractions
{
    public interface ILocationService
    {
        Task<Geolocation> GetLocationAsync(string address, CancellationToken ct = default);
    }
}