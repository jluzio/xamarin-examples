using System.Threading;
using System.Threading.Tasks;
using XamarinBootcamp.Core.Models;

namespace XamarinBootcamp.Core.Services.Abstractions
{
    public interface IAuthService
    {
        Task LoginAsync(string username, string password, CancellationToken ct = default(CancellationToken));

        Task LogoutAsync(CancellationToken ct = default(CancellationToken));

        bool IsUserAuthenticated();

        User.UserType GetAuthenticatedUserType();
    }
}