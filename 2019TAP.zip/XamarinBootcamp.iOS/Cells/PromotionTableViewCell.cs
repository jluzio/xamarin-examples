﻿using System;

using Foundation;
using UIKit;
using XamarinBootcamp.Core.Models;

namespace XamarinBootcamp.iOS.Cells
{
    public partial class PromotionTableViewCell : UITableViewCell
    {
        public static readonly NSString Key = new NSString("PromotionTableViewCell");
        public static readonly UINib Nib;

        static PromotionTableViewCell()
        {
            Nib = UINib.FromName("PromotionTableViewCell", NSBundle.MainBundle);
        }

        protected PromotionTableViewCell(IntPtr handle) : base(handle)
        {
            // Note: this .ctor should not contain any initialization logic.
        }

        public void SetupView(Promotion promotion)
        {
            NameLabel.Text = promotion.Product;
            DiscountLabel.Text = promotion.Discount.ToString("P");
        }
    }
}
