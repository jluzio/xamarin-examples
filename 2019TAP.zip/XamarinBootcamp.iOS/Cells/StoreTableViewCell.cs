﻿using System;
using System.Diagnostics;
using FFImageLoading;
using Foundation;
using UIKit;
using XamarinBootcamp.Core.Models;
using XamarinBootcamp.iOS.Helpers;

namespace XamarinBootcamp.iOS.Cells
{
    public partial class StoreTableViewCell : UITableViewCell
    {
        public static readonly NSString Key = new NSString("StoreTableViewCell");
        public static readonly UINib Nib;

        static StoreTableViewCell()
        {
            Nib = UINib.FromName("StoreTableViewCell", NSBundle.MainBundle);
        }

        protected StoreTableViewCell(IntPtr handle) : base(handle)
        {
            // Note: this .ctor should not contain any initialization logic.
        }

        public void SetupView(Store store)
        {
            try
            {
                ImageService.Instance.LoadUrl(store.PhotoUrl).IntoAsync(Image);
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
            
            NameLabel.Text = store.Name;
            AddressLabel.Text = store.Address;
        }
    }
}
