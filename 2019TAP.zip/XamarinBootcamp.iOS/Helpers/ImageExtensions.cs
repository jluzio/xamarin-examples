﻿using System;
using System.Diagnostics;
using Foundation;
using UIKit;

namespace XamarinBootcamp.iOS.Helpers
{
    public static class ImageExtensions
    {
        public static void LoadFromUrl(this UIImageView imageView, string uri)
        {
            try
            {
                using (var url = new NSUrl(uri))
                using (var data = NSData.FromUrl(url))
                    imageView.Image = UIImage.LoadFromData(data);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }
    }
}
