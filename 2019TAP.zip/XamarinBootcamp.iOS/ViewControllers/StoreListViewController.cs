﻿using System;
using System.ComponentModel;
using UIKit;
using XamarinBootcamp.Core;
using XamarinBootcamp.Core.Models;
using XamarinBootcamp.Core.ViewModels;
using XamarinBootcamp.iOS.Cells;
using XamarinBootcamp.iOS.Sources;

namespace XamarinBootcamp.iOS.ViewControllers
{
    public partial class StoreListViewController : UIViewController
    {
        private StoreListViewModel _viewModel;

        public StoreListViewController() : base("StoreListViewController", null)
        {
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            // Perform any additional setup after loading the view, typically from a nib.
            _viewModel = App.Container.GetInstance<StoreListViewModel>();

            Title = "Stores";
            
            StoresTableView.Source = new StoreListTableViewSource(_viewModel);
            StoresTableView.RegisterNibForCellReuse(StoreTableViewCell.Nib, StoreTableViewCell.Key);
            StoresTableView.EstimatedRowHeight = 150.0f;

            _viewModel.RefreshListCommand?.Execute(null);

            _viewModel.PropertyChanged -= ViewModelOnPropertyChanged;
            _viewModel.PropertyChanged += ViewModelOnPropertyChanged;
        }

        private void ViewModelOnPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(_viewModel.Stores))
                StoresTableView.ReloadData();
        }

        public override void DidReceiveMemoryWarning()
        {
            base.DidReceiveMemoryWarning();
            // Release any cached data, images, etc that aren't in use.
        }
    }
}

