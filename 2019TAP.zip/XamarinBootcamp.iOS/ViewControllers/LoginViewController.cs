﻿using System;
using System.ComponentModel;
using UIKit;
using XamarinBootcamp.Core;
using XamarinBootcamp.Core.ViewModels;

namespace XamarinBootcamp.iOS.ViewControllers
{
    public partial class LoginViewController : UIViewController
    {
        private LoginViewModel _viewModel;

        public LoginViewController() : base("LoginViewController", null)
        {
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            // Perform any additional setup after loading the view, typically from a nib.
            
            _viewModel = App.Container.GetInstance<LoginViewModel>();

            UsernameTextField.EditingChanged -= UsernameTextFieldOnValueChanged;
            UsernameTextField.EditingChanged += UsernameTextFieldOnValueChanged;
            
            PasswordTextField.EditingChanged -= PasswordTextFieldOnValueChanged;
            PasswordTextField.EditingChanged += PasswordTextFieldOnValueChanged;
            
            LoginButton.TouchUpInside -= LoginButtonOnTouchUpInside;
            LoginButton.TouchUpInside += LoginButtonOnTouchUpInside;
            
            _viewModel.PropertyChanged += ViewModelOnPropertyChanged;
        }

        private void ViewModelOnPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(_viewModel.Username))
                UsernameTextField.Text = _viewModel.Username;
            else if (e.PropertyName == nameof(_viewModel.Password))
                PasswordTextField.Text = _viewModel.Password;
        }

        private void UsernameTextFieldOnValueChanged(object sender, EventArgs e)
        {
            _viewModel.SetUsernameCommand?.Execute(UsernameTextField.Text);
        }
        
        private void PasswordTextFieldOnValueChanged(object sender, EventArgs e)
        {
            _viewModel.SetPasswordCommand?.Execute(PasswordTextField.Text);
        }
        
        private void LoginButtonOnTouchUpInside(object sender, EventArgs e)
        {
            NavigationController.SetViewControllers(new UIViewController[] { new MenuViewController() }, true);
            //_viewModel.LoginCommand?.Execute(null);
        }

        public override void DidReceiveMemoryWarning()
        {
            base.DidReceiveMemoryWarning();
            // Release any cached data, images, etc that aren't in use.
        }
    }
}

