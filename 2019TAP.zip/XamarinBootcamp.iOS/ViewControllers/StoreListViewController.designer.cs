﻿// WARNING
//
// This file has been generated automatically by Rider IDE
//   to store outlets and actions made in Xcode.
// If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using Foundation;
using System.CodeDom.Compiler;

namespace XamarinBootcamp.iOS.ViewControllers
{
	[Register ("StoreListViewController")]
	partial class StoreListViewController
	{
		[Outlet]
		UIKit.UIButton CreateStoreButton { get; set; }

		[Outlet]
		UIKit.UITableView StoresTableView { get; set; }

		void ReleaseDesignerOutlets ()
		{
			if (CreateStoreButton != null) {
				CreateStoreButton.Dispose ();
				CreateStoreButton = null;
			}

			if (StoresTableView != null) {
				StoresTableView.Dispose ();
				StoresTableView = null;
			}

		}
	}
}
