﻿using System;

using UIKit;
using XamarinBootcamp.Core;
using XamarinBootcamp.Core.ViewModels;

namespace XamarinBootcamp.iOS.ViewControllers
{
    public partial class MenuViewController : UIViewController
    {
        private MenuViewModel _viewModel;

        public MenuViewController() : base("MenuViewController", null)
        {
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            // Perform any additional setup after loading the view, typically from a nib.
            _viewModel = App.Container.GetInstance<MenuViewModel>();
            
            StoresButton.TouchUpInside -= StoresButtonOnTouchUpInside;
            StoresButton.TouchUpInside += StoresButtonOnTouchUpInside;
            
            PromotionsButton.TouchUpInside -= PromotionsButtonOnTouchUpInside;
            PromotionsButton.TouchUpInside += PromotionsButtonOnTouchUpInside;

            LogoutButton.TouchUpInside -= LogoutButtonOnTouchUpInside;
            LogoutButton.TouchUpInside += LogoutButtonOnTouchUpInside;
        }

        private void StoresButtonOnTouchUpInside(object sender, EventArgs e)
        {
            _viewModel.OpenStoresCommand?.Execute(null);
        }
        
        private void PromotionsButtonOnTouchUpInside(object sender, EventArgs e)
        {
            _viewModel.OpenPromotionsCommand?.Execute(null);
        }

        private void LogoutButtonOnTouchUpInside(object sender, EventArgs e)
        {
            NavigationController.SetViewControllers(new UIViewController[] { new LoginViewController() }, true);
        }

        public override void DidReceiveMemoryWarning()
        {
            base.DidReceiveMemoryWarning();
            // Release any cached data, images, etc that aren't in use.
        }
    }
}

