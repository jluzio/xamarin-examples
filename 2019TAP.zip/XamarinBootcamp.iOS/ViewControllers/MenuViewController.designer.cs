// WARNING
//
// This file has been generated automatically by Visual Studio to store outlets and
// actions made in the UI designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using Foundation;
using System.CodeDom.Compiler;

namespace XamarinBootcamp.iOS.ViewControllers
{
	[Register ("MenuViewController")]
	partial class MenuViewController
	{
		[Outlet]
		UIKit.UIButton LogoutButton { get; set; }

		[Outlet]
		UIKit.UIButton MapButton { get; set; }

		[Outlet]
		UIKit.UIButton PromotionsButton { get; set; }

		[Outlet]
		UIKit.UIButton StoresButton { get; set; }
		
		void ReleaseDesignerOutlets ()
		{
			if (StoresButton != null) {
				StoresButton.Dispose ();
				StoresButton = null;
			}

			if (PromotionsButton != null) {
				PromotionsButton.Dispose ();
				PromotionsButton = null;
			}

			if (MapButton != null) {
				MapButton.Dispose ();
				MapButton = null;
			}

			if (LogoutButton != null) {
				LogoutButton.Dispose ();
				LogoutButton = null;
			}
		}
	}
}
