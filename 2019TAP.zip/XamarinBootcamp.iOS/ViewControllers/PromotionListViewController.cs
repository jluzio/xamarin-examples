﻿using System;
using System.ComponentModel;
using UIKit;
using XamarinBootcamp.Core;
using XamarinBootcamp.Core.ViewModels;
using XamarinBootcamp.iOS.Cells;
using XamarinBootcamp.iOS.Sources;

namespace XamarinBootcamp.iOS.ViewControllers
{
    public partial class PromotionListViewController : UIViewController
    {
        private PromotionListViewModel _viewModel;

        public PromotionListViewController() : base("PromotionListViewController", null)
        {
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            // Perform any additional setup after loading the view, typically from a nib.
            _viewModel = App.Container.GetInstance<PromotionListViewModel>();

            Title = "Promotions";

            PromotionTableView.Source = new PromotionListTableViewSource(_viewModel);
            PromotionTableView.RegisterNibForCellReuse(PromotionTableViewCell.Nib, PromotionTableViewCell.Key);
            PromotionTableView.EstimatedRowHeight = 100.0f;

            _viewModel.RefreshListCommand?.Execute(null);

            _viewModel.PropertyChanged -= ViewModelOnPropertyChanged;
            _viewModel.PropertyChanged += ViewModelOnPropertyChanged;
        }

        private void ViewModelOnPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(_viewModel.Promotions))
                PromotionTableView.ReloadData();
        }

        public override void DidReceiveMemoryWarning()
        {
            base.DidReceiveMemoryWarning();
            // Release any cached data, images, etc that aren't in use.
        }
    }
}

