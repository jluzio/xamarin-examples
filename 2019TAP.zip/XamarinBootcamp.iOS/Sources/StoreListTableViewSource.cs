using System;
using Foundation;
using UIKit;
using XamarinBootcamp.Core.ViewModels;
using XamarinBootcamp.iOS.Cells;

namespace XamarinBootcamp.iOS.Sources
{
    public class StoreListTableViewSource : UITableViewSource
    {
        private readonly StoreListViewModel _storeListViewModel;

        public StoreListTableViewSource(StoreListViewModel storeListViewModel)
        {
            _storeListViewModel = storeListViewModel;
        }
        
        public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
        {
            StoreTableViewCell cell = tableView.DequeueReusableCell(StoreTableViewCell.Key, indexPath) as StoreTableViewCell;
            cell.SetupView(_storeListViewModel.Stores[indexPath.Row]);
            return cell;
        }
        
        public override nint RowsInSection(UITableView tableview, nint section) => _storeListViewModel.Stores?.Count ?? 0;
    }
}