using System;
using Foundation;
using UIKit;
using XamarinBootcamp.Core.ViewModels;
using XamarinBootcamp.iOS.Cells;

namespace XamarinBootcamp.iOS.Sources
{
    public class PromotionListTableViewSource : UITableViewSource
    {
        private PromotionListViewModel _promotionListViewModel;

        public PromotionListTableViewSource(PromotionListViewModel promotionListViewModel)
        {
            _promotionListViewModel = promotionListViewModel;
        }
        
        public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
        {
            PromotionTableViewCell cell = tableView.DequeueReusableCell(PromotionTableViewCell.Key, indexPath) as PromotionTableViewCell;
            cell.SetupView(_promotionListViewModel.Promotions[indexPath.Row]);
            return cell;
        }

        public override nint RowsInSection(UITableView tableview, nint section) => _promotionListViewModel.Promotions?.Count ?? 0;
    }
}