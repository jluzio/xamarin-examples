using System.Collections.Generic;
using Android.Support.V7.Widget;
using Android.Views;
using Java.Lang;
using XamarinBootcamp.Core.Models;
using XamarinBootcamp.Core.ViewModels;
using XamarinBootcamp.Droid.ViewHolders;

namespace XamarinBootcamp.Droid.Adapters
{
    public class StoresAdapter : RecyclerView.Adapter
    {
        private readonly StoreListViewModel _storeListViewModel;

        public StoresAdapter(StoreListViewModel storeListViewModel)
        {
            _storeListViewModel = storeListViewModel;
        }
        
        public override void OnBindViewHolder(RecyclerView.ViewHolder holder, int position)
        {
            if (holder is StoreViewHolder vh)
            {
                var store = _storeListViewModel.Stores[position];
                vh.SetupView(store);
            }
        }

        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            LayoutInflater inflater = LayoutInflater.From(parent.Context);
            View itemView = inflater.Inflate(Resource.Layout.viewholder_store, parent, false);
            var vh = new StoreViewHolder(itemView);
            return vh;
        }

        public override void OnViewRecycled(Object holder)
        {
            if (holder is StoreViewHolder vh)
                vh.Recycle();
        }

        public override int ItemCount => _storeListViewModel.Stores?.Count ?? 0;
    }
}