using Android.Support.V7.Widget;
using Android.Views;
using XamarinBootcamp.Core.ViewModels;
using XamarinBootcamp.Droid.ViewHolders;

namespace XamarinBootcamp.Droid.Adapters
{
    public class PromotionsAdapter : RecyclerView.Adapter
    {
        private readonly PromotionListViewModel _promotionListViewModel;

        public PromotionsAdapter(PromotionListViewModel promotionListViewModel)
        {
            _promotionListViewModel = promotionListViewModel;
        }
        
        public override void OnBindViewHolder(RecyclerView.ViewHolder holder, int position)
        {
            if (holder is PromotionViewHolder vh)
            {
                var promotion = _promotionListViewModel.Promotions[position];
                vh.Setup(promotion);
            }
        }

        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            LayoutInflater inflater = LayoutInflater.From(parent.Context);
            View itemView = inflater.Inflate(Resource.Layout.viewholder_promotion, parent, false);
            var vh = new PromotionViewHolder(itemView);
            return vh;
        }

        public override int ItemCount => _promotionListViewModel.Promotions?.Count ?? 0;
    }
}