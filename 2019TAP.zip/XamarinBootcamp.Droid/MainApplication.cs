using System;
using Android.App;
using Android.Runtime;
using GalaSoft.MvvmLight.Views;
using XamarinBootcamp.Core;
using XamarinBootcamp.Core.Services.Abstractions;
using XamarinBootcamp.Droid.Activities;
using XamarinBootcamp.Droid.Services;

namespace XamarinBootcamp.Droid
{
#if DEBUG
    [Application(Debuggable = true, Theme = "@style/AppTheme")]
#else
    [Application(Debuggable = false, Theme = "@style/AppTheme")]
#endif
    public class MainApplication : Application
    {
        protected MainApplication(IntPtr javaReference, JniHandleOwnership transfer) : base(javaReference, transfer)
        {
        }
        
        public override void OnCreate()
        {
            base.OnCreate();
            
            App.InitializeServices();
            RegisterPlatformServices();
            RegisterNavigation();
        }

        private void RegisterPlatformServices()
        {
            App.Container.Register<IDialogService, DialogService>();
            App.Container.Register<ILocationService, LocationService>();
        }

        private void RegisterNavigation()
        {
            var nav = new NavigationService();
            
            nav.Configure(NavigationConstants.LoginPage, typeof(LoginActivity));
            nav.Configure(NavigationConstants.MenuPage, typeof(MenuActivity));
            nav.Configure(NavigationConstants.StoresList, typeof(StoreListActivity));
            nav.Configure(NavigationConstants.CreateStore, typeof(CreateStoreActivity));
            nav.Configure(NavigationConstants.PromotionsList, typeof(PromotionListActivity));
            nav.Configure(NavigationConstants.StoreMapPage, typeof(StoreMapActivity));
            
            App.Container.Register<INavigationService>(() => nav);
        }
    }
}