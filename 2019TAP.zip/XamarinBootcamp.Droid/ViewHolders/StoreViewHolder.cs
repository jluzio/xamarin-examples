using System;
using Android.Runtime;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using Bumptech.Glide;
using XamarinBootcamp.Core.Models;

namespace XamarinBootcamp.Droid.ViewHolders
{
    public class StoreViewHolder : RecyclerView.ViewHolder
    {
        private ImageView _storeImage;
        private TextView _storeName;
        private TextView _storeAddress;
        private View _itemView;

        public StoreViewHolder(View itemView) : base(itemView)
        {
            _itemView = itemView;
            _storeImage = itemView.FindViewById<ImageView>(Resource.Id.storeImage);
            _storeName = itemView.FindViewById<TextView>(Resource.Id.storeName);
            _storeAddress = itemView.FindViewById<TextView>(Resource.Id.storeAddress);
        }

        public void SetupView(Store store)
        {
            if (!string.IsNullOrEmpty(store.PhotoUrl)) 
                Glide.With(_itemView.Context).Load(store.PhotoUrl).Into(_storeImage);

            _storeName.Text = store.Name;
            _storeAddress.Text = store.Address;
        }

        public void Recycle()
        {
            Glide.With(_itemView.Context).Clear(_storeImage);
        }
    }
}