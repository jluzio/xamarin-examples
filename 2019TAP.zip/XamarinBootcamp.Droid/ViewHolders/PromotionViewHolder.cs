using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using XamarinBootcamp.Core.Models;

namespace XamarinBootcamp.Droid.ViewHolders
{
    public class PromotionViewHolder : RecyclerView.ViewHolder
    {
        private View _itemView;
        private TextView _productName;
        private TextView _productDiscount;

        public PromotionViewHolder(View itemView) : base(itemView)
        {
            _itemView = itemView;
            _productName = itemView.FindViewById<TextView>(Resource.Id.productName);
            _productDiscount = itemView.FindViewById<TextView>(Resource.Id.productDiscount);
        }

        public void Setup(Promotion promotion)
        {
            _productName.Text = promotion.Product;
            _productDiscount.Text = promotion.Discount.ToString("P");
        }
    }
}