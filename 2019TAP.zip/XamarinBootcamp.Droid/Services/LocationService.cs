using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Android.Locations;
using GalaSoft.MvvmLight.Views;
using Java.Lang;
using XamarinBootcamp.Core.Models;
using XamarinBootcamp.Core.Services.Abstractions;

namespace XamarinBootcamp.Droid.Services
{
    public class LocationService : ILocationService
    {
        public async Task<Geolocation> GetLocationAsync(string address, CancellationToken ct = default)
        {
            var geocoder = new Geocoder(ActivityBase.CurrentActivity);
            
            var addresses = await geocoder.GetFromLocationNameAsync(address, 1);

            var first = addresses.FirstOrDefault();

            if (first == null)
                throw new Exception("No results found.");

            return new Geolocation
            {
                Latitude = first.Latitude.ToString(CultureInfo.InvariantCulture),
                Longitude = first.Longitude.ToString(CultureInfo.InvariantCulture)
            };
        }
    }
}