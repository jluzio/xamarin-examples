using System;
using System.ComponentModel;
using Android.App;
using Android.OS;
using Android.Views;
using Android.Widget;
using GalaSoft.MvvmLight.Views;
using XamarinBootcamp.Core;
using XamarinBootcamp.Core.ViewModels;

namespace XamarinBootcamp.Droid.Activities
{
    [Activity(Label = "CreateStoreActivity", Theme = "@style/AppTheme")]
    public class CreateStoreActivity : ActivityBase
    {
        private EditText _name;
        private EditText _address;
        private EditText _phone;
        private EditText _photoUrl;
        private ProgressBar _progressBar;
        private Button _doneButton;
        private CreateStoreViewModel _viewModel;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.activity_create_store);
            _viewModel = App.Container.GetInstance<CreateStoreViewModel>();

            _name = FindViewById<EditText>(Resource.Id.name);
            _address = FindViewById<EditText>(Resource.Id.address);
            _phone = FindViewById<EditText>(Resource.Id.phone);
            _photoUrl = FindViewById<EditText>(Resource.Id.photoUrl);
            _progressBar = FindViewById<ProgressBar>(Resource.Id.progressBar);
            _doneButton = FindViewById<Button>(Resource.Id.doneButton);
            
            _doneButton.Click -= DoneButtonOnClick;
            _doneButton.Click += DoneButtonOnClick;
            
            _viewModel.PropertyChanged -= ViewModelOnPropertyChanged;
            _viewModel.PropertyChanged += ViewModelOnPropertyChanged;
            
            _viewModel.CreateStoreCommand.CanExecuteChanged -= CreateStoreCommandOnCanExecuteChanged;
            _viewModel.CreateStoreCommand.CanExecuteChanged += CreateStoreCommandOnCanExecuteChanged;
            
            _progressBar.Visibility = _viewModel.IsBusy ? ViewStates.Visible : ViewStates.Gone;

            _name.TextChanged += (sender, args) => _viewModel.SetNameCommand?.Execute(args.Text.ToString());
            _address.TextChanged += (sender, args) => _viewModel.SetAddressCommand?.Execute(args.Text.ToString());
            _phone.TextChanged += (sender, args) => _viewModel.SetPhoneCommand?.Execute(args.Text.ToString());
            _photoUrl.TextChanged += (sender, args) => _viewModel.SetPhotoUrlCommand?.Execute(args.Text.ToString());
        }

        private void ViewModelOnPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            switch (e.PropertyName)
            {
                case nameof(_viewModel.IsBusy):
                    _progressBar.Visibility = _viewModel.IsBusy ? ViewStates.Visible : ViewStates.Gone;
                    break;
                case nameof(_viewModel.Name):
                    _name.Text = _viewModel.Name;
                    break;
                case nameof(_viewModel.Address):
                    _address.Text = _viewModel.Address;
                    break;
                case nameof(_viewModel.Phone):
                    _phone.Text = _viewModel.Phone;
                    break;
                case nameof(_viewModel.PhotoUrl):
                    _photoUrl.Text = _viewModel.PhotoUrl;
                    break;
            }
        }

        private void DoneButtonOnClick(object sender, EventArgs e)
        {
            if (_viewModel.CreateStoreCommand != null && _viewModel.CreateStoreCommand.CanExecute(null))
                _viewModel.CreateStoreCommand?.Execute(null);
        }
        
        private void CreateStoreCommandOnCanExecuteChanged(object sender, EventArgs e)
        {
            _doneButton.Enabled = _viewModel.CreateStoreCommand.CanExecute(null);
        }
    }
}