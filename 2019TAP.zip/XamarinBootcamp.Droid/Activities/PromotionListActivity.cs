using System;
using System.ComponentModel;
using Android.App;
using Android.OS;
using Android.Support.V4.Widget;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using GalaSoft.MvvmLight.Views;
using XamarinBootcamp.Core;
using XamarinBootcamp.Core.ViewModels;
using XamarinBootcamp.Droid.Adapters;

namespace XamarinBootcamp.Droid.Activities
{
    [Activity(Label = "PromotionListActivity", Theme = "@style/AppTheme")]
    public class PromotionListActivity : ActivityBase
    {
        private PromotionListViewModel _viewModel;
        
        private RecyclerView _promotionsRecyclerView;
        private PromotionsAdapter _promotionsAdapter;
        private SwipeRefreshLayout _promotionsSwipeRefreshLayout;
        private ProgressBar _progressBar;
        private Button _createButton;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.activity_promotion_list);
            _viewModel = App.Container.GetInstance<PromotionListViewModel>();
            
            _promotionsRecyclerView = FindViewById<RecyclerView>(Resource.Id.promotionsRecyclerView);
            _promotionsSwipeRefreshLayout = FindViewById<SwipeRefreshLayout>(Resource.Id.promotionsSwipeRefreshLayout);
            _progressBar = FindViewById<ProgressBar>(Resource.Id.progressBar);
            _createButton = FindViewById<Button>(Resource.Id.createButton);


            _promotionsAdapter = new PromotionsAdapter(_viewModel);
            _promotionsRecyclerView.SetLayoutManager(new LinearLayoutManager(this));
            _promotionsRecyclerView.SetAdapter(_promotionsAdapter);
            
            _viewModel.RefreshListCommand?.Execute(null);
            
            _viewModel.PropertyChanged -= ViewModelOnPropertyChanged;
            _viewModel.PropertyChanged += ViewModelOnPropertyChanged;
            
            _promotionsSwipeRefreshLayout.Refresh -= PromotionsSwipeRefreshLayoutOnRefresh;
            _promotionsSwipeRefreshLayout.Refresh += PromotionsSwipeRefreshLayoutOnRefresh;
            
            _createButton.Click -= CreateButtonOnClick;
            _createButton.Click += CreateButtonOnClick;
        }

        private void PromotionsSwipeRefreshLayoutOnRefresh(object sender, EventArgs e)
        {
            _viewModel.RefreshListCommand?.Execute(null);
            _promotionsSwipeRefreshLayout.Refreshing = false;
        }

        private void CreateButtonOnClick(object sender, EventArgs e)
        {
//            _viewModel.CreatePromotionCommand?.Execute(null);
        }

        private void ViewModelOnPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(_viewModel.Promotions))
                _promotionsAdapter.NotifyDataSetChanged();
            else if (e.PropertyName == nameof(_viewModel.IsBusy))
                _progressBar.Visibility = _viewModel.IsBusy ? ViewStates.Visible : ViewStates.Gone;
        }
    }
}