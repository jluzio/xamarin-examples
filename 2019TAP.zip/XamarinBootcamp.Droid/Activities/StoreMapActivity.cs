using Android.App;
using Android.Gms.Maps;
using Android.OS;
using GalaSoft.MvvmLight.Views;
using XamarinBootcamp.Core;
using XamarinBootcamp.Core.ViewModels;

namespace XamarinBootcamp.Droid.Activities
{
    [Activity(Label = "StoreMapActivity", Theme = "@style/AppTheme")]
    public class StoreMapActivity : ActivityBase, IOnMapReadyCallback
    {
        private StoreMapViewModel _viewModel;
        
        private MapView _mapView;
        private GoogleMap _map;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            SetContentView(Resource.Layout.activity_store_map);
            _viewModel = App.Container.GetInstance<StoreMapViewModel>();

            _mapView = FindViewById<MapView>(Resource.Id.mapView);
            _mapView.OnCreate(bundle);
            
            _mapView.GetMapAsync(this);
        }

        public void OnMapReady(GoogleMap googleMap)
        {
            _map = googleMap;
        }
    }
}