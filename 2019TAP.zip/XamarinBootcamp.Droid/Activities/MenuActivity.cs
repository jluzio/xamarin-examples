using System;
using Android.App;
using Android.OS;
using Android.Widget;
using GalaSoft.MvvmLight.Views;
using XamarinBootcamp.Core;
using XamarinBootcamp.Core.ViewModels;

namespace XamarinBootcamp.Droid.Activities
{
    [Activity(Label = "MenuActivity", Theme = "@style/AppTheme")]
    public class MenuActivity : ActivityBase
    {
        private MenuViewModel _viewModel;
        
        private Button _storesButton;
        private Button _promotionsButton;
        private Button _mapButton;
        private Button _logoutButton;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.activity_menu);
            _viewModel = App.Container.GetInstance<MenuViewModel>();

            _storesButton = FindViewById<Button>(Resource.Id.menu_stores_button);
            _promotionsButton = FindViewById<Button>(Resource.Id.menu_promotions_button);
            _mapButton = FindViewById<Button>(Resource.Id.menu_map_button);
            _logoutButton = FindViewById<Button>(Resource.Id.logout_button);
            
            _storesButton.Click += StoresButtonOnClick;
            _promotionsButton.Click += PromotionsButtonOnClick;
            _mapButton.Click += MapButtonOnClick;
            _logoutButton.Click += LogoutButtonOnClick;
        }

        private void StoresButtonOnClick(object sender, EventArgs e)
        {
            _viewModel.OpenStoresCommand?.Execute(null);
        }
        
        private void PromotionsButtonOnClick(object sender, EventArgs e)
        {
            _viewModel.OpenPromotionsCommand?.Execute(null);
        }
        
        private void MapButtonOnClick(object sender, EventArgs e)
        {
            _viewModel.OpenStoreMapCommand?.Execute(null);
        }
        
        private void LogoutButtonOnClick(object sender, EventArgs e)
        {
            _viewModel.LogoutCommand?.Execute(null);
        }
    }
}