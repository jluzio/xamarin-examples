using System;
using System.ComponentModel;
using Android.App;
using Android.OS;
using Android.Support.V4.Widget;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using GalaSoft.MvvmLight.Views;
using XamarinBootcamp.Core;
using XamarinBootcamp.Core.ViewModels;
using XamarinBootcamp.Droid.Adapters;

namespace XamarinBootcamp.Droid.Activities
{
    [Activity(Label = "StoreListActivity", Theme = "@style/AppTheme")]
    public class StoreListActivity : ActivityBase
    {
        private StoreListViewModel _viewModel;
        private RecyclerView _storesRecyclerView;
        private StoresAdapter _storesAdapter;
        private SwipeRefreshLayout _storesSwipeRefreshLayout;
        private ProgressBar _progressBar;
        private Button _createButton;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.activity_store_list);
            _viewModel = App.Container.GetInstance<StoreListViewModel>();

            _storesRecyclerView = FindViewById<RecyclerView>(Resource.Id.storesRecyclerView);
            _storesSwipeRefreshLayout = FindViewById<SwipeRefreshLayout>(Resource.Id.storesSwipeRefreshLayout);
            _progressBar = FindViewById<ProgressBar>(Resource.Id.progressBar);
            _createButton = FindViewById<Button>(Resource.Id.createButton);
            
            _storesAdapter = new StoresAdapter(_viewModel);
            _storesRecyclerView.SetLayoutManager(new LinearLayoutManager(this));
            _storesRecyclerView.SetAdapter(_storesAdapter);

            _viewModel.RefreshListCommand?.Execute(null);
            
            _viewModel.PropertyChanged -= ViewModelOnPropertyChanged;
            _viewModel.PropertyChanged += ViewModelOnPropertyChanged;
            
            _storesSwipeRefreshLayout.Refresh -= StoresSwipeRefreshLayoutOnRefresh;
            _storesSwipeRefreshLayout.Refresh += StoresSwipeRefreshLayoutOnRefresh;
            
            _createButton.Click -= CreateButtonOnClick;
            _createButton.Click += CreateButtonOnClick;
        }

        private void ViewModelOnPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(_viewModel.Stores))
                _storesAdapter.NotifyDataSetChanged();
            else if (e.PropertyName == nameof(_viewModel.IsBusy))
                _progressBar.Visibility = _viewModel.IsBusy ? ViewStates.Visible : ViewStates.Gone;
        }
        
        private void StoresSwipeRefreshLayoutOnRefresh(object sender, EventArgs e)
        {
            _viewModel.RefreshListCommand?.Execute(null);
            _storesSwipeRefreshLayout.Refreshing = false;
        }
        
        private void CreateButtonOnClick(object sender, EventArgs e)
        {
            _viewModel.CreateStoreCommand?.Execute(null);
        }
    }
}