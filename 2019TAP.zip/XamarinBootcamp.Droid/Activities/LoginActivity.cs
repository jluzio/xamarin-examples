using System;
using System.ComponentModel;
using Android.App;
using Android.OS;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using GalaSoft.MvvmLight.Helpers;
using GalaSoft.MvvmLight.Views;
using XamarinBootcamp.Core;
using XamarinBootcamp.Core.ViewModels;

namespace XamarinBootcamp.Droid.Activities
{
    [Activity(Label = "LoginActivity", Theme = "@style/AppTheme")]
    public class LoginActivity : ActivityBase
    {
        private LoginViewModel _viewModel;
        
        private EditText _username;
        private EditText _password;
        private Button _loginButton;
        private ProgressBar _progressBar;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.activity_login);
            _viewModel = App.Container.GetInstance<LoginViewModel>();

            _username = FindViewById<EditText>(Resource.Id.Username);
            _password = FindViewById<EditText>(Resource.Id.Password);
            _loginButton = FindViewById<Button>(Resource.Id.LoginButton);
            _progressBar = FindViewById<ProgressBar>(Resource.Id.ProgressBar);

            _username.Text = _viewModel.Username;
            _password.Text = _viewModel.Password;
            _progressBar.Visibility = _viewModel.IsBusy ? ViewStates.Visible : ViewStates.Invisible;

            _loginButton.Click += (sender, args) =>
            {

                if (_viewModel.LoginCommand.CanExecute(null))
                {
                    _viewModel.LoginCommand.ExecuteAsync();
                }
            };

            _username.TextChanged +=
                (sender, args) => _viewModel.SetUsernameCommand?.Execute(args.Text.ToString());
            
            _password.TextChanged +=
                (sender, args) => _viewModel.SetPasswordCommand?.Execute(args.Text.ToString());
            
            _viewModel.PropertyChanged += ViewModelOnPropertyChanged;
            
            _viewModel.LoginCommand.CanExecuteChanged += LoginCommandOnCanExecuteChanged;
        }

        private void ViewModelOnPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            switch (e.PropertyName)
            {
                case nameof(_viewModel.Username):
                    _username.Text = _viewModel.Username;
                    break;
                case nameof(_viewModel.Password):
                    _password.Text = _viewModel.Password;
                    break;
                case nameof(_viewModel.IsBusy):
                    _progressBar.Visibility = _viewModel.IsBusy ? ViewStates.Visible : ViewStates.Invisible;
                    break;
            }
        }
        
        private void LoginCommandOnCanExecuteChanged(object sender, EventArgs e)
        {
            _loginButton.Enabled = _viewModel.LoginCommand.CanExecute(null);
        }
    }
}