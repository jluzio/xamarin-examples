using Acr.UserDialogs;
using Android.App;
using Android.OS;
using Android.Support.V7.App;
using GalaSoft.MvvmLight.Views;
using XamarinBootcamp.Core;

namespace XamarinBootcamp.Droid.Activities
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = true)]
    public class SplashScreenActivity : ActivityBase
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            UserDialogs.Init(this);
        }

        protected override void OnResume()
        {
            base.OnResume();
            App.Start();
        }
    }
}