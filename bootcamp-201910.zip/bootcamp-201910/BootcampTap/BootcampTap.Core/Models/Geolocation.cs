﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BootcampTap.Core.Models
{
    public class Geolocation
    {
        public string Latitude { get; set; }
        public string Longitude { get; set; }
    }
}
